package com.tmf.customer.restapi.customerrest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerRestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
